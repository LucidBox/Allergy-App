//
//  ViewController.swift
//  MyCareListProject
//
//  Created by Viet Nguyen on 18/04/2022.
//

import UIKit
import Firebase
import FirebaseAuth
import FirebaseFirestoreSwift


//MARK: - TO DO-LIST


//SECURITY
//* Security rules 

//UI UPDATES
//* ordered array - lower and high caps for globalallergy
//* UI update - cells with shadows and padding + corners


//EXTRA FUNCTIONS
//* Edit active contactlists



class MainViewController: UIViewController {
    
   
    


    @IBOutlet weak var allergiesTableView: UITableView!
    
    @IBOutlet weak var addButton: UIButton!
    
    @IBOutlet weak var contactsButton: UIButton!
    
    @IBOutlet weak var checkButton: UIButton!
    

    @IBOutlet weak var myView: UIView!
    
    //reference to Firestore
    let db = Firestore.firestore()

    //*************  initialize careBrain
    var careBrain = CareBrain()
    

    
    
    var contactNamesArray = [String]()
    
    var allergyDictionary = [String: String]()
    
//MARK: - GLOBAL VARIABLES
    
    //************   initialize Global Contact List
    var globalContactList: [Contact] = []
   
    
    //************   initialize Global Allergy List
    var globalAllergyList = [String]()
    

    //************   initialize Active Allergy List
    var activeAllergyList = [String]()
    
    //************   initialize matchedContacts Array
    var matchedContacts = [String]()
    //************   initialize matchedAllergies array
    var matchedAllergies = [String: [String]]()
    
 

    
 //MARK: - VIEWDIDLOAD
    
 
    
 
    
    override func viewDidLoad() {
        super.viewDidLoad()
    
        
        myView.layer.cornerRadius = 35
       
     
        
        //hide back button
        self.navigationItem.setHidesBackButton(true, animated: true)
        

        
        //reload globalContactList from fireBase
        reloadContactsromFirebase()
        
        //reload globalAllergyList from fireBase
        reloadAllergyFromFirebase()
        

     
      
        //set tableView delegate to this class
        allergiesTableView.delegate = self
        
        //set tableView datasource to this class
        allergiesTableView.dataSource = self
        
        //register tableView with customized nib
        allergiesTableView.register(UINib(nibName: "AllergyCell", bundle: nil), forCellReuseIdentifier: "AllergyCell")
        
        
     

   
        
        
    }


    @IBAction func settingsButtonPressed(_ sender: UIButton) {
        
        //go to SettingsVC
        self.performSegue(withIdentifier: "goToSettings", sender: self)
    }
    
    

    
 
       
    
    
   
    
    
    func reloadContactsromFirebase() {
        guard let userID = Auth.auth().currentUser?.uid else { return }
     
        print("RELOADING CONTACTS")
        
        let docRef = db.collection("users").document(userID)
        docRef.getDocument(source: .cache) { (document, error) in

  
            
            if let document = document {
                let property = document.get("globalContactList") as! [String: [String]]
                
              
                
                for fieldValue in property {
             
                  
                    self.globalContactList.append(Contact(contactName: fieldValue.key, contactAllergies: fieldValue.value))
                    
          
                    self.globalContactList = self.globalContactList.sorted { $0.contactName.lowercased() < $1.contactName.lowercased() }
                    
                    
        
                }
            } else {
                print("Document does not exist in cache")
            }
        }
        
        
       
    }

    
    func reloadAllergyFromFirebase() {
        guard let userID = Auth.auth().currentUser?.uid else { return }
     
        print("RELOADING ALLERGIES")
        
        let docRef = db.collection("users").document(userID)
        docRef.getDocument(source: .cache) { (document, error) in
            if let document = document {
               
                let property = document.get("globalAllergyList") as! [String]
                for fieldValue in property {
                    if !self.globalAllergyList.contains(fieldValue) {  self.globalAllergyList.append(fieldValue)}
                  
                    
                    self.globalAllergyList.sort()
                    //UPDATE tableView content
                    self.reloadTableView()
                }
            } else {
                print("Document does not exist in cache")
            }
        }
            
    }
    
    func reloadTableView() {
        DispatchQueue.main.async {
        //reload data
        self.allergiesTableView.reloadData()
        }
        
    }
  




    
  //MARK: - GO TO SEGUE

    @IBAction func checkButtonPressed(_ sender: Any) {
        
        //run checkAllergy Function
        matchedContacts = careBrain.checkAllergy(activeAllergyList: activeAllergyList, contactList: globalContactList)
        
        //run checkMatchedAllergies Function
       matchedAllergies = careBrain.checkMatchedAllergies(activeAllergyList: activeAllergyList, contactList: globalContactList)
        
        print("MATCHED ALLERGIES DICTIONARY: \(matchedAllergies)")
        
        //go to MatchedVC
        self.performSegue(withIdentifier: "goToMatchedVC", sender: self)
        
        
    }
   
    
    @IBAction func contactsButtonPressed(_ sender: UIButton) {
            self.performSegue(withIdentifier: "goToContactVC", sender: self)
        
    }
    
    
   
    @IBAction func addButtonPressed(_ sender: UIButton) {
       
            self.performSegue(withIdentifier: "goToAddGlobalAllergy", sender: self)
        }
        
        
    
  
         
    
    


    
//MARK: - PREPARE SEGUE
    
    
    //Prepare segue
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "goToMatchedVC" {
            //prepare variables
            let destinationVC = segue.destination as! MatchedViewController
            
             destinationVC.activeAllergyList = activeAllergyList
             destinationVC.globalAllergyList = globalAllergyList
             destinationVC.globalContactList = globalContactList
             destinationVC.matchedContacts = matchedContacts
             destinationVC.matchedAllergies = matchedAllergies
           
        }
        
        
        if segue.identifier == "goToContactVC" {
            let destinationVC = segue.destination as! ContactsViewController
            destinationVC.globalContactList = globalContactList
            destinationVC.globalAllergyList = globalAllergyList
            
            destinationVC.delegate = self
            
        }
        
        if segue.identifier == "goToAddGlobalAllergy" {
            let destinationVC = segue.destination as! AddGlobalAllergyViewController
            destinationVC.globalAllergyList = globalAllergyList
            destinationVC.globalContactList = globalContactList
         
        }
        
        if segue.identifier == "goToSettings" {
            let destinationVC = segue.destination as! SettingsViewController
            destinationVC.globalAllergyList = globalAllergyList
            destinationVC.globalContactList = globalContactList
            
        }
        
       
        
    }
    
    
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        
        allergiesTableView.reloadData()
        
        //reset arrays
        matchedContacts.removeAll()
        activeAllergyList.removeAll()
        print("Reloading allergiesTableView + Reseting arrays")
        
    }
    
}





//MARK: - DELEGATE EXTENSIONS

extension MainViewController: UITableViewDataSource, UITableViewDelegate  {
    //specify number of rows in TableView
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return globalAllergyList.count
    }
    
    //specify look in each cell
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        //identify count number of the allergy
        let allergy = globalAllergyList[indexPath.row]
        
        //create reusable cell
        let cell = allergiesTableView.dequeueReusableCell(withIdentifier: "AllergyCell", for: indexPath) as! AllergyCell
        //populate each cell with following:
        cell.label.text = allergy
        

        let result = activeAllergyList.contains(allergy)
        
        if (result) {
     
            cell.backgroundColor = UIColor(red: 246 / 255.0, green: 204 / 255.0, blue: 171 / 255.0, alpha: 1.0)
          } else {

            cell.backgroundColor = UIColor(red: 243 / 255.0, green: 245 / 255.0, blue: 248 / 255.0, alpha: 1.0)
        }
        
        return cell
    }
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        //identify count number of the allergy
        
        let allergy = globalAllergyList[indexPath.row]
        let indexesToRedraw = [indexPath]
      
       
        print(allergy)
        

        
        if activeAllergyList.contains(allergy) {
            
           
            //! LATER UPDATE: if there are no allergies in globalAllergyList
                activeAllergyList.remove(at: activeAllergyList.firstIndex(of: allergy)!)
                print("removing \(allergy) from the activeAllergyList: \(activeAllergyList)")
            
           
        } else {
          
      
                activeAllergyList.append(allergy)
                print(activeAllergyList)
        }
     
        // reload
        tableView.reloadRows(at: indexesToRedraw, with: .fade)

    }
    
    func tableView(_ tableView: UITableView, editingStyleForRowAt indexPath: IndexPath) -> UITableViewCell.EditingStyle {
        return .delete
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            tableView.beginUpdates()
             
            globalAllergyList.remove(at: indexPath.row)
            print("UPDATING DATA")
            careBrain.updateGlobalAllergyList(allergyList: globalAllergyList)
            print(globalAllergyList)
            
            tableView.deleteRows(at: [indexPath], with: .fade)
            tableView.endUpdates()
        }
    }


    //! LATER UPDATE: IF no allergies in globalAllergyList
    
}

extension MainViewController: SendDataToPreviousVCProtocol {
    func sendDataBack(myData: [Contact]) {
        globalContactList.removeAll()
        globalContactList.append(contentsOf: myData)
        print("SENDING DATA BACK TO MAIN VIEW")
        
    }
}

