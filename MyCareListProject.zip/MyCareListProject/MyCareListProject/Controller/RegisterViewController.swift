//
//  RegisterViewController.swift
//  MyCareListProject
//
//  Created by Viet Nguyen on 16/05/2022.
//

import UIKit
import Firebase


class RegisterViewController: UIViewController {
    
  
    @IBOutlet weak var emailTextField: UITextField!
    
    @IBOutlet weak var passwordTextField: UITextField!

    
    //reference to Firestore
    let db = Firestore.firestore()


    

    
    
    @IBAction func registerPressed(_ sender: UIButton) {
        
        if let email = emailTextField.text, let password = passwordTextField.text {
            //Create User
            Auth.auth().createUser(withEmail: email, password: password) { authResult, error in
                if let e = error {
                    print(e.localizedDescription)
                    // create the alert
                    let alert = UIAlertController(title: "Error", message: "Email must be valid and password must be 6 characters long or more.", preferredStyle: .alert)
                    //
                    //
                     //add button
                    alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
                                                
                    //present alert
                    self.present(alert, animated: true, completion: nil)

                } else {
                 
                    guard let userID = Auth.auth().currentUser?.uid else { return }
                    
                    //Create User Document
                    self.db.collection("users").document(userID).setData([
                        "globalContactList": [String: Any](),
                        "globalAllergyList": ["Nuts", "Fish", "Eggs", "Milk", "Gluten", "Sesame", "Shellfish", "Soy", "Wheat"]
                    ]) {
                        error in
                        if let error = error {
//
    
                            
                            print("Error writing document: \(error)")
                        } else {
                            print("Document successfully written!")
                        }
                    }
                    
                    //navigate to MainViewController
                    self.performSegue(withIdentifier: "registerToMain", sender: self)
                
                   
             
                }
                
                
                
            }
            
        }
        
    }
 
  
}
