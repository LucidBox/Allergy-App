//
//  welcomeViewController.swift
//  MyCareListProject
//
//  Created by Viet Nguyen on 16/05/2022.
//

import Foundation
import UIKit
import Firebase
import FirebaseAuth
import FirebaseFirestoreSwift

//reference to Firestore
let db = Firestore.firestore()

class WelcomeViewController: UIViewController {
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
   
        
        navigationController?.isNavigationBarHidden = true
    
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        navigationController?.isNavigationBarHidden = false
    
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
 

    }
 
  
}
    

