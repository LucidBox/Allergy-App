//
//  ContactProfileViewController.swift
//  MyCareListProject
//
//  Created by Viet Nguyen on 24/04/2022.
//


import Foundation
import UIKit



class ContactProfileViewController: UIViewController  {

    var globalContactList = [Contact]()
    var globalAllergyList = [String]()
    var contact = Contact(contactName: "Default", contactAllergies: ["Default"])
    var newContact = Contact(contactName: "Default2", contactAllergies: ["Default2"])
   
    var careBrain = CareBrain()
    var delegate: SendDataToPreviousVCProtocol?
    
    @IBOutlet weak var contactNameLabel: UILabel!
    @IBOutlet weak var allergyLabel: UILabel!
    @IBOutlet weak var contactAllergyTableView: UITableView!
    

    
    override func viewDidLoad() {
        super.viewDidLoad()
    
        //set tableView datasource to this class
        contactAllergyTableView.dataSource = self
        
        //register tableView with customized nib
        contactAllergyTableView.register(UINib(nibName: "AllergyCell", bundle: nil), forCellReuseIdentifier: "AllergyCell")
    
        
        contactNameLabel.text = contact.contactName
 
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        
        self.contact.contactAllergies.sort()
        contactAllergyTableView.reloadData()
        
        
        
    }
    
 
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)

  
        
        if self.isMovingFromParent {
            let myData = globalContactList
            
            self.delegate?.sendDataBack(myData: myData)
        
        }
    }
    

    

    
    
    @IBAction func addButtonPressed(_ sender: UIButton) {
        if (contact.contactAllergies.count < globalAllergyList.count) {
        
        self.performSegue(withIdentifier: "addAllergyToContact", sender: self)
        } else {
            // create the alert
            let alert = UIAlertController(title: "Info", message: "No more allergies to add!", preferredStyle: .alert)
            //
            //
             //add button
            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
                                        
            //present alert
            self.present(alert, animated: true, completion: nil)

        }
    
    }
    
    //Prepare segue
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "addAllergyToContact" {
            //prepare variables
            let destinationVC = segue.destination as! AddAllergyToContact
            
             destinationVC.contact = contact
             destinationVC.globalAllergyList = globalAllergyList
             destinationVC.globalContactList = globalContactList
           
        }
    
    }
    

}


//MARK: - DELEGATE EXTENSIONS

extension ContactProfileViewController: UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return contact.contactAllergies.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        //identify the contact object in current indexPath
        let allergy = contact.contactAllergies[indexPath.row]
        
        //populate each cell in the tableView with following:
        let cell = contactAllergyTableView.dequeueReusableCell(withIdentifier: "AllergyCell", for: indexPath) as! AllergyCell
        
        //populate each allergyCell text with following:
        cell.label.text = allergy
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, editingStyleForRowAt indexPath: IndexPath) -> UITableViewCell.EditingStyle {
        return .delete
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            tableView.beginUpdates()
             

           
            //update var contact
            contact.contactAllergies.remove(at: indexPath.row)
            
            //update var globalContactList
            if let index = globalContactList.firstIndex(where: {$0.contactName == contact.contactName}) {
                globalContactList[index].contactAllergies = contact.contactAllergies
            }
            
           
          
         
            print("UPDATING DATA")
            careBrain.updateGlobalContactList(contactList: globalContactList)
           
            
            tableView.deleteRows(at: [indexPath], with: .fade)
            tableView.endUpdates()
        
        }
    }
    
    
}
