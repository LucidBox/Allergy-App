//
//  SettingsViewController.swift
//  MyCareListProject
//
//  Created by Viet Nguyen on 21/07/2022.
//

import Foundation
import UIKit
import Firebase




class SettingsViewController: UIViewController {
    var globalAllergyList = [String]()
    var globalContactList = [Contact]()
    
    var careBrain = CareBrain()
   
    @IBOutlet weak var logOutButton: UIButton!
    @IBOutlet weak var deleteButton: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        logOutButton.layer.cornerRadius = 10
        deleteButton.layer.cornerRadius = 10
    }
 
    
        @IBAction func logOutPressed(_ sender: UIButton) {
    
            // create the alert
            let alert = UIAlertController(title: "Info", message: "Are you sure you want to log out?", preferredStyle: .alert)
            //
            //
             //add button
            alert.addAction(UIAlertAction(title: "Log Out", style: .default, handler: {_ in
                do {
                    self.careBrain.updateGlobalAllergyList(allergyList: self.globalAllergyList)
                    self.careBrain.updateGlobalContactList(contactList: self.globalContactList)
    
                    try Auth.auth().signOut()
                    //jump to root VC
                    self.navigationController?.popToRootViewController(animated: true)
                    print("USER LOGGED OUT")
    
                } catch let signOutError as NSError {
                        print("Error signing out: %@", signOutError)
                    }
            }))
            alert.addAction(UIAlertAction(title: "Cancel", style: .default, handler: nil))
    
            //present alert
            self.present(alert, animated: true, completion: nil)
    
    
    
    
    
            }
    
    @IBAction func deleteUserPressed(_ sender: UIButton) {
        
        // create the alert
        let alert = UIAlertController(title: "Info", message: "Are you sure you want to delete the user? List of contacts and allergies will be deleted permanently.", preferredStyle: .alert)
        
        //add button
       alert.addAction(UIAlertAction(title: "Yes, I am sure", style: .default, handler: {_ in
           
               let user = Auth.auth().currentUser

               user?.delete { error in
                 if let error = error {
                   // An error happened.
                     print(error.localizedDescription)
                 } else {
                   // Account deleted.
                     //jump to root VC
                     self.navigationController?.popToRootViewController(animated: true)
                     print("USER LOGGED OUT")
                 }
               }
           }
       ))
        
        alert.addAction(UIAlertAction(title: "Cancel", style: .default, handler: nil))
        
        //present alert
        self.present(alert, animated: true, completion: nil)
        
    }
        
}
