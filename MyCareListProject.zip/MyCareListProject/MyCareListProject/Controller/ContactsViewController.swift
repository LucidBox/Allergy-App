//
//  ContactsViewController.swift
//  MyCareListProject
//
//  Created by Viet Nguyen on 24/04/2022.
//

import Foundation

import UIKit

protocol SendDataToPreviousVCProtocol {
    func sendDataBack(myData: [Contact])
}

class ContactsViewController: UIViewController {
  
    
    
   
    var globalContactList = [Contact]()
    var globalAllergyList = [String]()
    var contact = Contact(contactName: "Default", contactAllergies: ["Default"])
    
    var careBrain = CareBrain()
    var delegate: SendDataToPreviousVCProtocol?
    
    @IBOutlet weak var contactsTableView: UITableView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        print("ContactsViewController: viewDidLoad - globalContactList: \(globalContactList)")
        print("ContactsViewController: viewDidLoad- globalAllergyList: \(globalAllergyList)")
        
        //set tableView delegate to this class
        contactsTableView.delegate = self
        
        //set tableView datasource to this class
        contactsTableView.dataSource = self
        
        //register tableView with customized nib
        contactsTableView.register(UINib(nibName: "ContactCell", bundle: nil), forCellReuseIdentifier: "ContactCell")
    
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        
        self.globalContactList = self.globalContactList.sorted { $0.contactName.lowercased() < $1.contactName.lowercased() }
        
        contactsTableView.reloadData()
        
        
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)

        if self.isMovingFromParent {
            let myData = globalContactList
            self.delegate?.sendDataBack(myData: myData)
          
        }
    }
    
    @IBAction func addContactButton(_ sender: UIButton) {
        self.performSegue(withIdentifier: "goToAddContact", sender: self)
    }
    
    //Prepare segue
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if segue.identifier == "goToContactProfileVC" {
            //prepare variables
            let destinationVC = segue.destination as! ContactProfileViewController
            
             destinationVC.contact = contact
             destinationVC.globalAllergyList = globalAllergyList
             destinationVC.globalContactList = globalContactList
            
            destinationVC.delegate = self
            
        }
        if segue.identifier == "goToAddContact" {
            //prepare variables
            let destinationVC = segue.destination as! AddContactViewController
            destinationVC.globalAllergyList = globalAllergyList
            destinationVC.globalContactList = globalContactList
    }
    
 }
    
}
//MARK: - DELEGATE EXTENSIONS

extension ContactsViewController: UITableViewDataSource, UITableViewDelegate {
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return globalContactList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        //identify the contact object in current indexPath
        let contact = globalContactList[indexPath.row]
        
        //populate each cell in the tableView with following:
        let cell = contactsTableView.dequeueReusableCell(withIdentifier: "ContactCell", for: indexPath) as! ContactCell
        //populate each contactCell text with following:
        cell.label.text = contact.contactName
        
        
        return cell
    }
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        //identify count number of the allergy
        contact = globalContactList[indexPath.row]
        
        
        self.performSegue(withIdentifier: "goToContactProfileVC", sender: self)
    
       
   
    }
    
    func tableView(_ tableView: UITableView, editingStyleForRowAt indexPath: IndexPath) -> UITableViewCell.EditingStyle {
        return .delete
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            tableView.beginUpdates()
             
            globalContactList.remove(at: indexPath.row)
            print("UPDATING DATA")
            careBrain.updateGlobalContactList(contactList: globalContactList)
            print(globalContactList)
            
            tableView.deleteRows(at: [indexPath], with: .fade)
            tableView.endUpdates()
        }
    }
}
    
extension ContactsViewController: SendDataToPreviousVCProtocol {
    func sendDataBack(myData: [Contact]) {
        globalContactList.removeAll()
        globalContactList.append(contentsOf: myData)
        print("SENDING DATA BACK TO PREVIOUS VIEW")
    }
}

    

