//
//  LogInViewController.swift
//  MyCareListProject
//
//  Created by Viet Nguyen on 16/05/2022.
//


import UIKit
import Firebase




class LogInViewController: UIViewController {
    
  
    
    @IBOutlet weak var emailTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!
    


    @IBAction func logInPressed(_ sender: UIButton) {
        if let email = emailTextField.text, let password = passwordTextField.text {
            Auth.auth().signIn(withEmail: email, password: password) { authResult, error in
                if let e = error {
                    print(e.localizedDescription)
                    // create the alert
                    let alert = UIAlertController(title: "Error", message: "Invalid Email or Password - Please try again.", preferredStyle: .alert)
                    //
                    //
                     //add button
                    alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
                                                
                    //present alert
                    self.present(alert, animated: true, completion: nil)
                    
                } else {
                    self.performSegue(withIdentifier: "logInToMain", sender: self)
                    
                    
                  
                }
            }
        }
    }
    
    

}
