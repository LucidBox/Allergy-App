//
//  AddContactViewController.swift
//  MyCareListProject
//
//  Created by Viet Nguyen on 28/04/2022.
//


import Foundation
import UIKit
import FirebaseAuth
import FirebaseFirestoreSwift





class AddContactViewController: UIViewController, UITextFieldDelegate {
    
    @IBOutlet weak var contactNameTextField: UITextField!
    
    @IBOutlet weak var allergyTableView: UITableView!
    var globalAllergyList = [String]()
    var globalContactList = [Contact]()
    var activeAllergyArray = [String]()
    
    var careBrain = CareBrain()

 
    
    override func viewDidLoad() {
        super.viewDidLoad()
        print("AddContactViewController: viewDidLoad - globalContactList: \(globalContactList)")
        print("AddContactViewController: viewDidLoad- globalAllergyList: \(globalAllergyList)")
        //set tableView delegate to this class
        allergyTableView.delegate = self
        
        //set tableView datasource to this class
        allergyTableView.dataSource = self
        
        //register tableView with customized nib
        allergyTableView.register(UINib(nibName: "AllergyCell", bundle: nil), forCellReuseIdentifier: "AllergyCell")
        
        //specify what will call delegate
        contactNameTextField.delegate = self

        
    }
    
    
    
    @IBAction func addButtonPressed(_ sender: UIButton) {
        
        if let contactName = contactNameTextField.text {
            
            let checkIfUserExists = checkIfUserExists()
            
            if(checkIfUserExists) {
                if(contactName != "") {
                    globalContactList.append(Contact(contactName: contactName, contactAllergies: activeAllergyArray))
                    
                    print("AddContactViewController: addButtonPressed - globalContactList: \(globalContactList)")
                    print("AddContactViewController: addButtonPressed - globalAllergyList: \(globalAllergyList)")
                    
                    //dismiss keyboard
                    contactNameTextField.endEditing(true)
                    
                    //empty textField
                    contactNameTextField.text = ""
                    
                    //empty activeAllergyArray
                    activeAllergyArray.removeAll()
                   
                  

                //pop viewControllers back to mainVC
                  backToMainVC()
                  
                }
            } else {
                // create the alert
                let alert = UIAlertController(title: "Contact Name already exists", message: "Names in your Contact List must be unique.", preferredStyle: .alert)
                //
                //
                 //add button
                alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
                                            
                //present alert
                self.present(alert, animated: true, completion: nil)
                
            }
            
        
        }
        

    }
    
  
 
 
 //MARK: - <#Section Heading#>   Pop viewControllers back to mainVC
    func backToMainVC() {
        for vc in self.navigationController!.viewControllers {
            if let myViewCont = vc as? MainViewController
            {
                
                //UPDATING CONTACTS & ALLERGIES
                print("UPDATING DATA")
                careBrain.updateGlobalAllergyList(allergyList: globalAllergyList)
                careBrain.updateGlobalContactList(contactList: globalContactList)
                
                
                myViewCont.globalContactList = globalContactList
                myViewCont.globalAllergyList = globalAllergyList
                self.navigationController?.popToViewController(myViewCont, animated: true)
            }
        }
    
   }
    
    
    
    
    
//MARK: - TEXTFIELD DELEGATE METHODS
    //what happens when return button is pressed on keyboard
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        if textField.text != "" {
            contactNameTextField.endEditing(true)
            return true
        } else {
            //do not allow end editing the textField
            return false
        }
    }
    
    //what happebs if user taps elsewhere than textField
    func textFieldShouldEndEditing(_ textField: UITextField) -> Bool {
        if textField.text != "" {
            contactNameTextField.endEditing(true)
            return true
            } else {
                //do not allow end editing textField
                return false
            }
        }
    
    func checkIfUserExists() -> Bool {
        let results = globalContactList.filter { $0.contactName == contactNameTextField.text }
        let exists = results.isEmpty
        return exists
    }
    
    
    
}
//MARK: - DELEGATE EXTENSIONS

extension AddContactViewController: UITableViewDataSource, UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return globalAllergyList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let allergy = globalAllergyList[indexPath.row]
        
        let cell = allergyTableView.dequeueReusableCell(withIdentifier: "AllergyCell", for: indexPath) as! AllergyCell
        
        cell.label.text = allergy
        
        
        let result = activeAllergyArray.contains(allergy)
        
        if (result) {

            cell.backgroundColor = UIColor(red: 246 / 255.0, green: 204 / 255.0, blue: 171 / 255.0, alpha: 1.0)
          } else {

            cell.backgroundColor = UIColor(red: 243 / 255.0, green: 245 / 255.0, blue: 248 / 255.0, alpha: 1.0)
        }
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
       let allergy = globalAllergyList[indexPath.row]
        
        let indexesToRedraw = [indexPath]
        
        if (activeAllergyArray.contains(allergy)) {
            //! LATER UPDATE: if there are no allergies in globalAllergyList
                activeAllergyArray.remove(at: activeAllergyArray.firstIndex(of: allergy)!)
                print("removing allergy from the activeAllergyArray: \(activeAllergyArray)")
      
        } else {
                activeAllergyArray.append(allergy)
                print(activeAllergyArray)
             
        }
        
        // reload
        tableView.reloadRows(at: indexesToRedraw, with: .fade)
        
        
    }
    
    
}
