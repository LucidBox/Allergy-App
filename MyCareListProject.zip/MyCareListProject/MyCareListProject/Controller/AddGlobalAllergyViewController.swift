//
//  addGlobalAllergyViewController.swift
//  MyCareListProject
//
//  Created by Viet Nguyen on 24/04/2022.
//

import Foundation
import UIKit
import FirebaseAuth
import FirebaseFirestoreSwift



class AddGlobalAllergyViewController: UIViewController, UITextFieldDelegate {
    
    var globalAllergyList = [String]()
    var globalContactList = [Contact]()
    var careBrain = CareBrain()
    
   
  
    @IBOutlet weak var allergyNameTextField: UITextField!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        print(globalAllergyList)
        
        //specify what will call delegate
        allergyNameTextField.delegate = self
    
        
    }
    
    
 
    @IBAction func addButtonPressed(_ sender: UIButton) {
        //add allergy to Global allergyList by optional binding
        if let allergyName = allergyNameTextField.text {
            if(allergyName != "") {
                globalAllergyList.append(allergyName)
                //dismiss keyboard
                allergyNameTextField.endEditing(true)
                //empty textField
                allergyNameTextField.text = ""
                
                backToMainVC()
              
                
           
        
            }
        }
    }
    
    
    //MARK: - <#Section Heading#>   Pop viewControllers back to mainVC
       func backToMainVC() {
           for vc in self.navigationController!.viewControllers {
               if let myViewCont = vc as? MainViewController
               {
                   
                   //UPDATING CONTACTS & ALLERGIES
                   print("UPDATING DATA")
                   careBrain.updateGlobalAllergyList(allergyList: globalAllergyList)
                   careBrain.updateGlobalContactList(contactList: globalContactList)
                   
                   
                   myViewCont.globalContactList = globalContactList
                   myViewCont.globalAllergyList = globalAllergyList
                   self.navigationController?.popToViewController(myViewCont, animated: true)
               }
           }
       
      }
       
    

    
    
    
    
 //MARK: - TEXTFIELD DELEGATE METHODS
    //what happens when return button is clicked on keyboard
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        if textField.text != "" {
            //dismiss keyboard
            allergyNameTextField.endEditing(true)
            return true
        } else {
            //do not allow user to end editing the textfield
            return false
        }
    }
    
    //what happens if user taps elsewhere than textfield
    func textFieldShouldEndEditing(_ textField: UITextField) -> Bool {
        if textField.text != "" {
            allergyNameTextField.endEditing(true)
            return true
        } else {
            //do not allow user to end editing the textfield
            return false
        }
    }
    

}

