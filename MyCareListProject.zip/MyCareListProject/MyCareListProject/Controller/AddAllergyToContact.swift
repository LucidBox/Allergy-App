//
//  AddAllergyToContact.swift
//  MyCareListProject
//
//  Created by Viet Nguyen on 26/04/2022.
//

import Foundation
import UIKit
import FirebaseAuth
import FirebaseFirestoreSwift

class AddAllergyToContact: UIViewController {
    
    var globalAllergyList = [String]()
    var globalContactList = [Contact]()
    var contact = Contact(contactName: "Default", contactAllergies: ["Default"])
    var newContact = Contact(contactName: "Default", contactAllergies: ["Default"])
    
    
    var contactAllergies = [String]()
    var filteredGlobalAllergies = [String]()
    
    var careBrain = CareBrain()
    
    @IBOutlet weak var allergiesTableView: UITableView!

  
    override func viewDidLoad() {
        super.viewDidLoad()
        //filter allergies
        contactAllergies = contact.contactAllergies
        filteredGlobalAllergies = Array(Set(globalAllergyList).subtracting(Set(contactAllergies)))
        filteredGlobalAllergies.sort()
        
       
        //set tableView delegate to this class
        allergiesTableView.delegate = self
        
        //set tableView datasource to this class
        allergiesTableView.dataSource = self
        
        //register tableView with customized nib
        allergiesTableView.register(UINib(nibName: "AllergyCell", bundle: nil), forCellReuseIdentifier: "AllergyCell")
        
        print("Add allergy to contact: \(contact)")
        print("Add allergy to contact: \(globalAllergyList)")
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
      
    }
    
    
    @IBAction func addButtonPressed(_ sender: UIButton) {
        

        
      backToMainVC()
          
    }
    

  
//MARK: - <#Section Heading#>   Pop viewControllers back to mainVC
       func backToMainVC() {
           for vc in self.navigationController!.viewControllers {
               if let myViewCont = vc as? MainViewController
               {

                   
                   //update var globalContactList
                   if let index = globalContactList.firstIndex(where: {$0.contactName == contact.contactName}) {
                       globalContactList[index].contactAllergies = contact.contactAllergies
                   }
                   
                  
                   
                   
                   
                   //UPDATING CONTACTS & ALLERGIES
                   print("UPDATING DATA")
                   careBrain.updateGlobalAllergyList(allergyList: globalAllergyList)
                   careBrain.updateGlobalContactList(contactList: globalContactList)
                   
                   
                    myViewCont.globalContactList = globalContactList
                    myViewCont.globalAllergyList = globalAllergyList
                  
                   
                   
                   self.navigationController?.popToViewController(myViewCont, animated: true)
               }
           }
       
      }

}



//MARK: - DELEGATE EXTENSIONS
extension AddAllergyToContact: UITableViewDataSource, UITableViewDelegate {
    


    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return filteredGlobalAllergies.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
 
        //identify object in current indexPath
        let allergy = filteredGlobalAllergies[indexPath.row]
        
        //populate each cell with following:
        let cell = allergiesTableView.dequeueReusableCell(withIdentifier: "AllergyCell", for: indexPath) as! AllergyCell
        
        //populate each cell with following text:
        cell.label.text = allergy
        

        
        
        let result = contact.contactAllergies.contains(allergy)
        
        if (result) {

            cell.backgroundColor = UIColor(red: 246 / 255.0, green: 204 / 255.0, blue: 171 / 255.0, alpha: 1.0)
          } else {

            cell.backgroundColor = UIColor(red: 243 / 255.0, green: 245 / 255.0, blue: 248 / 255.0, alpha: 1.0)
        }
      
        
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
      
        
        //identify object in currenct indexPath
        let allergy = filteredGlobalAllergies[indexPath.row]
        
        let indexesToRedraw = [indexPath]
    
        
        if(contact.contactAllergies.contains(allergy)) {
            contact.contactAllergies.remove(at: contact.contactAllergies.firstIndex(of: allergy)!)
            print("removing allergy")
            print(contact)
        } else {
            contact.contactAllergies.append(allergy)
            print("adding allergy")
            print(contact)
        }
        
      
        // reload
        tableView.reloadRows(at: indexesToRedraw, with: .fade)
     
          
    }
    
    
    
}
