//
//  MatchedViewController.swift
//  MyCareListProject
//
//  Created by Viet Nguyen on 18/04/2022.
//

import Foundation
import UIKit



class MatchedViewController: UIViewController {
    
    @IBOutlet weak var activeAllergiesLabel: UILabel!
    
  
    @IBOutlet weak var noMatchLabel: UILabel!
    
    @IBOutlet weak var matchedTableView: UITableView!
    
    @IBOutlet weak var myStackView: UIStackView!
    
    @IBOutlet weak var myStackView2: UIStackView!
    
    var activeAllergyList = [String]()
    var globalAllergyList = [String]()
    var globalContactList = [Contact]()
    var matchedContacts = [String]()
    var matchedAllergies = [String: [String]]()
    

  
    
    override func viewDidLoad() {
        super.viewDidLoad()
    
        
        myStackView.layer.cornerRadius = 35
        myStackView.layer.masksToBounds = true
        
        myStackView2.layer.cornerRadius = 35
        myStackView2.layer.masksToBounds = true
        
        //Display labels
        activeAllergiesLabel.text = activeAllergyList.joined(separator: ", ")
       // matchedContactsLabel.text = matchedContacts.joined(separator: "\n ")
        
        //set tableView delegate to this class
        matchedTableView.delegate = self
        
        //set tableView datasource to this class
        matchedTableView.dataSource = self
        
        //register tableView with customized nib
        matchedTableView.register(UINib(nibName: "MatchedCell", bundle: nil), forCellReuseIdentifier: "MatchedCell")
        
        ifNoMatch()
    }
    
 
    func ifNoMatch() {
        if(matchedContacts.count <= 0) {
            noMatchLabel.text = "No matches found"
        }
    }
    
    

}


//MARK: - DELEGATE EXTENSIONS

extension MatchedViewController: UITableViewDataSource, UITableViewDelegate {
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return matchedContacts.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        //identify the contact object in current indexPath
        let contact = matchedContacts[indexPath.row]
        
        //identify matchedAllergies of the current contact from the matched allergies dictionary
        var currentMatchedAllergies = matchedAllergies[contact]
        
        currentMatchedAllergies?.sort()
        
        //populate each cell in the tableView with following:
        let cell = matchedTableView.dequeueReusableCell(withIdentifier: "MatchedCell", for: indexPath) as! MatchedCell
        //populate each contactCell text with following:
        cell.label.text = contact
        cell.subLabel.text = currentMatchedAllergies?.joined(separator: ", ")
        
        
        let backgroundView = UIView()
        backgroundView.backgroundColor = UIColor.white
        cell.selectedBackgroundView = backgroundView
        
        return cell
    }
    
}
