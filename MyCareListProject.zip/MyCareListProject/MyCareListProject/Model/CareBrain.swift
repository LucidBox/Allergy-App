//
//  CareBrain.swift
//  MyCareListProject
//
//  Created by Viet Nguyen on 18/04/2022.
//

import Foundation
import Firebase
import FirebaseAuth
import FirebaseFirestoreSwift

struct CareBrain {
    //reference to Firestore
    let db = Firestore.firestore()
    
    
    
    // CHECK MATCHED CONTACTS FUNCTION -> CREATES ARRAY OF MATCHED CONTACTS
    func checkAllergy(activeAllergyList: [String?], contactList: [Contact]) -> [String] {
    
        var matchedContacts = [String]()
        
        
        //ADD TO MATCHED CONTACT ARRAY
        contactList.forEach {contact in
            
            //identify allergies of the nth contact iteration in the global contactlist array
            let contactAllergies = contact.contactAllergies
            
            //check if matched with the active allergies
            let matchedContactsTest = Array(Set(contactAllergies).intersection(activeAllergyList))
            
            //add contact´s name to the matched contact array if anything is inside the mathcedContactsTest array
        
            if (matchedContactsTest.count > 0) {
                matchedContacts.append(contact.contactName)
            } else {
                return
            }
        }
        
        return matchedContacts
        
    }
    
    //CHECK MATCHED ALLERGIES FUNCTION -> CREATES A DICTIONARY OF MATCHED ALLERGIES
    func checkMatchedAllergies(activeAllergyList: [String], contactList: [Contact]) -> [String: [String]] {
        //create dictionary
        var matchedAllergiesArray = [String: [String]]()
        
        contactList.forEach {
            contact in
            //identify allergies of the nth contact iteration in the global contactlist array
            let contactAllergies = contact.contactAllergies
            //check if matched with the active allergies
            let matchedContactsTest = Array(Set(contactAllergies).intersection(activeAllergyList))
            
            //add to dictionary
            matchedAllergiesArray.updateValue(matchedContactsTest, forKey: contact.contactName)
          
        }
        return matchedAllergiesArray
      
    }
    

    //UPDATE GLOBAL ALLERGYLIST FUNCTION
    func updateGlobalAllergyList(allergyList: [String])  {
        guard let userID = Auth.auth().currentUser?.uid else { return }
            
        print("UPDATING ALLERGIES")
       
           db.collection("users").document(userID).updateData([
            "globalAllergyList": allergyList])
        { error in
            if let error = error {
                print("Error writing document: \(error)")
            } else {
                print("Document successfully written for globalAllergyList!")
            }
        }
}
    
    //UPDATE GLOBAL CONTACTLIST FUNCTION
    func updateGlobalContactList(contactList: [Contact]) {
       
        guard let userID = Auth.auth().currentUser?.uid else { return }
        print("UPDATING CONTACTS")
        
        var tempDict = [String: [String]]()
        
        for contact in contactList {
            tempDict.updateValue(contact.contactAllergies, forKey: contact.contactName)
        }
        
        db.collection("users").document(userID).updateData([
         "globalContactList": tempDict])
     { error in
         if let error = error {
             print("Error writing document: \(error)")
         } else {
             print("Document successfully written for globalAllergyList!")
         }
     }
       
    }
    
   
}
