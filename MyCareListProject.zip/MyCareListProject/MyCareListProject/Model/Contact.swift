//
//  Contact.swift
//  MyCareListProject
//
//  Created by Viet Nguyen on 18/04/2022.
//

import Foundation

struct Contact: Equatable, Codable {
    var contactName: String
    var contactAllergies: [String]
}
