//
//  MatchedCell.swift
//  MyCareListProject
//
//  Created by Viet Nguyen on 19/07/2022.
//

import UIKit

class MatchedCell: UITableViewCell {
    
    @IBOutlet weak var label: UILabel!

    @IBOutlet weak var subLabel: UILabel!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
