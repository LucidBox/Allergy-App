//
//  AllergyCell.swift
//  MyCareListProject
//
//  Created by Viet Nguyen on 18/04/2022.
//

import UIKit

class AllergyCell: UITableViewCell {

    @IBOutlet weak var label: UILabel!
    @IBOutlet weak var myView: UIView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        
        //rounded corners
        myView.layer.cornerRadius = myView.frame.size.height / 5
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()

      //  contentView.frame = contentView.frame.inset(by: UIEdgeInsets(top: 10, left: 10, bottom: 10, right: 10))
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
